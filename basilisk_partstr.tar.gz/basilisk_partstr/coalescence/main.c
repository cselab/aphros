#include "curvature_partstr.h"

#include "navier-stokes/centered.h"
#include "two-phase.h"
#include "vof.h"
#include "tension.h"

#include "vtk.h"

#include <assert.h>
#define myassert(EX) (void)((EX) || (__assert (#EX, __FILE__, __LINE__),0))

#define TMAX (0.5)
#define DUMPDT (0.01)

struct Bub {
  double x;
  double y;
  double z;
  double r;
} b, b2;

double ifr3(double x, double y, double z) {
  double r = sq(x - b.x) + sq(y - b.y) + sq(z - b.z);
  double r2 = sq(x - b2.x) + sq(y - b2.y) + sq(z - b2.z);
  return fmax(sq(b.r) - r, sq(b2.r) - r2);
}


int main() {
  init_grid(32);

  origin (0.,0.,0.);

  b.y = 0.5;
  b.z = 0.5;
  b.r = 0.2;
  b.x = 0.5 - b.r;

  b2.y = 0.5;
  b2.z = 0.5;
  b2.r = 0.2;
  b2.x = 0.5 + b2.r;


  rho2 = 1.;
  rho1 = 0.01;

  mu2 = 1e-3;
  mu1 = 1e-5;

  f.sigma = 0.1;

  DumpCsvInit();

  run();

  DumpCsvFin();
}

event init (i = 0) {
  fraction(f, ifr3(x, y, z));
}

event out (t += DUMPDT ; t <= TMAX) {
  printf("dump i=%05d t=%g dt=%g \n", i, t ,dt);

  char filename[1000];

  sprintf(filename, "facets_%04d.vtk", i);
  DumpFacets(f, filename);

  sprintf(filename, "part_%04d.csv", i);
  DumpCsv(filename);
}

event statout (i += 10 ; t <= TMAX) {
  printf("step i=%05d t=%g dt=%g \n", i, t ,dt);
}
