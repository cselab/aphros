#include <assert.h>
#include <mpi.h>

#include "fractions.h"
#include "curvature_partstr.h"

double levelset(double x, double y, double z) {
  double r = sqrt(sq(x - 0.5) + sq(y - 0.5) + sq(z - 0.5));
  r *= 1 + 0.3 * sin(x * 10) * sin(y * 15);
  return r - 0.3;
}

int main() {
  init_grid(32);

  scalar vf[];
  fraction(vf, levelset(x, y, z));

  scalar k[];
  boundary({vf});

  DumpCsvInit();

  curvature(vf, k);

  DumpFacets(vf, "facets.vtk");

  {
    FILE* f = fopen("curv", "w");
    foreach() {
      if (vf[] > 0. && vf[] < 1.) {
        fprintf(f, "%.16g\n", k[]);
      }
    }
    fclose(f);
  }
  DumpCsvFin();
}
