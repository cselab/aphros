#!/usr/bin/env python

import numpy as np
import sys
import os
import re

av = sys.argv

if len(av) < 3:
  sys.stderr.write(
"""usage: {:} A B [EPS=1e-8] [-sort] [-rel]
Compares words from A and B allowing tolerance EPS for numbers.
-sort: sort words alphabetically
-rel: use relative difference for numbers
Returns: 1 if different.
STDOUT: first failed pair
""".format(sys.argv[0]))
  exit(1)

fa = av[1]
fb = av[2]
eps = float(av[3]) if len(av) > 3 else 1e-8

# text
ua = open(fa).readlines()
ub = open(fb).readlines()

ua = ' '.join(ua)
ub = ' '.join(ub)

# words
pt='[ ,\t]'
wa = re.split(pt, ua)
wb = re.split(pt, ub)

if "-sort" in av:
  wa = sorted(wa)
  wb = sorted(wb)

rel = "-rel" in av



def E(a, b, e):
  global eps
  print("error exceeded: {:} > {:}\na='{:}' b='{:}', ".format(e, eps, a, b))
  exit(1)

la = len(wa)
lb = len(wb)

em = 0 # max diff

for i in range(max(la,lb)):
  i < la or E('', wb[i])
  i < lb or E(wa[i], '')

  a = wa[i]
  b = wb[i]
  if a == b:
    continue

  try:
    na = float(a)
    nb = float(b)
  except:
    E(a, b)

  if rel:
    e = (abs(na) + abs(nb)) * 0.5
    e = abs(na - nb) / e if e != 0 else 0
  else:
    e = abs(na - nb)

  em = max(em, e)

  e <= eps or all(np.isnan([na,nb])) or E(a, b, e)

print("max error: {:}".format(em))
